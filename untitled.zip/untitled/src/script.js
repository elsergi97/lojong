document.addEventListener('DOMContentLoaded', () => {
  // ========== GLOBAL STATE ==========
  const values = {};
  const logs = {};
  const cityEntries = {};
  let currentDate = new Date(2025, 0, 1);

  // All your labels
  const mentalStates = ['Dislike/Like','Control/Let Go','Envy/Love','Negativity/Positivity','Ego/Selfless'];
  const yinEnergies   = ['Frame/Control','Confidence/Leadership','Resilience/Courage'];
  const yangEnergies  = ['Purpose/Leadership','Honesty/Resilience','Courage/Decisive'];
  const diaries = {
    spain: ['Valencia','Barcelona','Madrid','Salamanca'],
    thailand: ['Bangkok','Pattaya','Udon Thani'],
    colombia: ['Bogota','Medellin','Bucaramanga'],
    philippines: ['Davao','Manila','Cebu','Boracay','Siquijor'],
    uk: ['London','Liverpool','Brighton']
  };

  // ========== INITIALIZATION ==========
  function init() {
    // Initialize value map
    [...mentalStates, ...yinEnergies, ...yangEnergies].forEach(label => {
      values[label] = 0;
    });

    bindAdjustButtons();
    animateAllBars();
    setupCalendar();
    setupFlags();
    updateOverall();
  }

  // ========== PROGRESS BAR LOGIC ==========
  function bindAdjustButtons() {
    document.querySelectorAll('.controls button').forEach(btn => {
      btn.addEventListener('click', e => {
        const delta = btn.textContent.includes('+') ? 1 : -1;
        const parent = btn.closest('.card, .state-card, .energy-card');
        const label = parent.querySelector('h3, h4').textContent;
        adjustValue(label, delta);
      });
    });
  }

  function adjustValue(label, delta) {
    values[label] = Math.min(100, Math.max(0, values[label] + delta));
    const key = label.replace(/[^a-zA-Z]/g, '');
    const fill = document.getElementById(`bar-${key}`);
    const val  = document.getElementById(`val-${key}`);
    fill.style.width = values[label] + '%';
    val.textContent = values[label] + '%';
    updateOverall();
  }

  function animateAllBars() {
    // stagger animation for visual flair
    let delay = 100;
    document.querySelectorAll('.mini-fill').forEach(fill => {
      const target = parseInt(fill.style.width);
      fill.style.width = '0%';
      setTimeout(() => {
        fill.style.transition = 'width 0.6s ease-out';
        fill.style.width = target + '%';
      }, delay);
      delay += 100;
    });
  }

  function updateOverall() {
    const sum = Object.values(values).reduce((a, b) => a + b, 0);
    const avg = Math.round(sum / Object.keys(values).length);
    document.getElementById('general-fill').style.width = avg + '%';
    document.getElementById('general-value').textContent = avg + '%';
  }

  // ========== CALENDAR LOGIC ==========
  function setupCalendar() {
    document.getElementById('prev-month').onclick = () => changeMonth(-1);
    document.getElementById('next-month').onclick = () => changeMonth(1);
    renderCalendar();
  }

  function changeMonth(offset) {
    currentDate.setMonth(currentDate.getMonth() + offset);
    renderCalendar();
  }

  function renderCalendar() {
    const month = currentDate.getMonth();
    const year  = currentDate.getFullYear();
    document.getElementById('current-month-year').textContent =
      currentDate.toLocaleString('default',{month:'long',year:'numeric'});
    const firstDay = new Date(year, month, 1).getDay();
    const totalDays = new Date(year, month+1, 0).getDate();
    const tbody = document.getElementById('calendar-body');
    tbody.innerHTML = '';

    let dayCounter = 1;
    for (let week = 0; week < 6; week++) {
      const tr = document.createElement('tr');
      for (let wd = 0; wd < 7; wd++) {
        const td = document.createElement('td');
        if (week === 0 && wd < firstDay || dayCounter > totalDays) {
          td.textContent = '';
        } else {
          td.textContent = dayCounter;
          td.addEventListener('click', () => selectDate(td, dayCounter));
          dayCounter++;
        }
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }
  }

  function selectDate(cell, day) {
    // clear previous
    document.querySelectorAll('#calendar-body td.selected')
      .forEach(td => td.classList.remove('selected'));
    cell.classList.add('selected');

    const key = `${currentDate.getMonth()+1}-${day}-${currentDate.getFullYear()}`;
    logs[key] = logs[key] || { note: '', effort: '' };
    document.getElementById('note-text').value = logs[key].note;
    document.getElementById('effort').value    = logs[key].effort;
  }

  document.querySelector('#calendar ~ .notes-panel button')
    .addEventListener('click', () => {
      const sel = document.querySelector('#calendar-body td.selected');
      if (!sel) return alert('Please select a date.');
      const day = sel.textContent;
      const key = `${currentDate.getMonth()+1}-${day}-${currentDate.getFullYear()}`;
      logs[key] = {
        note: document.getElementById('note-text').value,
        effort: document.getElementById('effort').value
      };
      alert('Log saved ✔️');
    });

  // ========== DIARY FLAGS & CITIES ==========
  function setupFlags() {
    document.querySelectorAll('.flag').forEach(flag => {
      flag.addEventListener('click', () => {
        const country = flag.textContent.codePointAt(0) === 0x1F1EA ? 'spain'
                     : flag.textContent === '🇹🇭' ? 'thailand'
                     : flag.textContent === '🇨🇴' ? 'colombia'
                     : flag.textContent === '🇵🇭' ? 'philippines'
                     : 'uk';
        showCities(country);
      });
    });
  }

  function showCities(country) {
    const container = document.getElementById('cities-container');
    container.innerHTML = ''; container.style.display = 'block';

    diaries[country].forEach(city => {
      const span = document.createElement('span');
      span.className = 'city';
      span.textContent = city;
      span.addEventListener('click', () => showJournal(country, city));
      container.appendChild(span);
    });
  }

  function showJournal(country, city) {
    const key = `${country}-${city}`;
    const container = document.getElementById('journal-container');
    container.innerHTML = ''; container.style.display = 'block';

    const header = document.createElement('h3');
    header.textContent = `Journal: ${city}`;
    container.appendChild(header);

    const entriesDiv = document.createElement('div');
    entriesDiv.className = 'entries';
    (cityEntries[key] || []).forEach((text, idx) => {
      entriesDiv.appendChild(createEntryBox(key, text, idx));
    });

    const addBtn = document.createElement('button');
    addBtn.className = 'add-entry';
    addBtn.textContent = 'Add New Entry';
    addBtn.addEventListener('click', () => {
      cityEntries[key] = cityEntries[key] || [];
      cityEntries[key].push('');
      entriesDiv.appendChild(createEntryBox(key, '', cityEntries[key].length - 1));
    });

    container.appendChild(entriesDiv);
    container.appendChild(addBtn);
  }

  function createEntryBox(key, text, idx) {
    const div = document.createElement('div');
    div.className = 'entry';
    const ta = document.createElement('textarea');
    ta.value = text;
    const btn = document.createElement('button');
    btn.textContent = 'Save';
    btn.addEventListener('click', () => {
      cityEntries[key][idx] = ta.value;
      alert('Entry saved!');
    });
    div.appendChild(ta);
    div.appendChild(btn);
    return div;
  }

  // Kick off
  init();
});
